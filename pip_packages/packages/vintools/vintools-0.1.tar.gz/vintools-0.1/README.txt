vintools

Python library to help with jupyter notebooks in vinted
